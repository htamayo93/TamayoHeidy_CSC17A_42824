/* 
 * File:   NumDays.h
 * Author: Heidy Tamayo
 * Created on May 9, 2016, 2:44 PM
 */

#include <iostream>
using namespace std;

#ifndef NUMDAYS2_H
#define	NUMDAYS2_H

class NumDays2 {
public:
    NumDays2();
    void setday(int);
    int getday();
private:
    int days;
};

#endif	/* NUMDAYS2_H */
