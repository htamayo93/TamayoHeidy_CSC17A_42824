var searchData=
[
  ['results',['Results',['../class_results.html',1,'Results'],['../class_results.html#acc0c6a11a0e0cb1aa4ad6156305833e9',1,'Results::results(string[], string[])'],['../class_results.html#ae15a9e843b67c54e98a6f59a56104e1f',1,'Results::Results()']]],
  ['results_2ecpp',['Results.cpp',['../_results_8cpp.html',1,'']]],
  ['results_2eh',['Results.h',['../_results_8h.html',1,'']]]
];
