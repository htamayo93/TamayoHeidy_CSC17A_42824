var searchData=
[
  ['changelimit',['changelimit',['../classchangelimit.html',1,'']]],
  ['computerpick',['ComputerPick',['../class_computer_pick.html',1,'']]]
];
