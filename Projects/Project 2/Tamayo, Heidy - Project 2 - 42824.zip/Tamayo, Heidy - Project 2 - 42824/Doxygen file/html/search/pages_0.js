var searchData=
[
  ['tamayoheidy_5fcsc17a_5f42824',['TamayoHeidy_CSC17A_42824',['../md_README.html',1,'']]]
];
