var searchData=
[
  ['setlimit',['setlimit',['../class_results.html#ae617cd43567d2a566ab9d5daae350884',1,'Results']]],
  ['setlimit2',['setlimit2',['../classchangelimit.html#a7943b11d48ad14546e519e02abc0f935',1,'changelimit']]],
  ['setn',['setn',['../class_results.html#a3c596a52f51171a4262c7508b4820179',1,'Results']]],
  ['setpick1',['setpick1',['../class_user_pick.html#a91db1caf95a828dd688072e63daa1b14',1,'UserPick']]],
  ['setpick2',['setpick2',['../class_user_pick.html#a6efd407101a5d6886e0b67b2617359bd',1,'UserPick']]],
  ['setpick3',['setpick3',['../class_user_pick.html#a48b3f245f3ac15829a071ef192b08b51',1,'UserPick']]],
  ['setpick4',['setpick4',['../class_user_pick.html#a2dc67209f51a094523e2521a54864225',1,'UserPick']]],
  ['setval',['setval',['../class_validation.html#a009490d0459132bdad4d000e48b1e1ea',1,'Validation']]]
];
