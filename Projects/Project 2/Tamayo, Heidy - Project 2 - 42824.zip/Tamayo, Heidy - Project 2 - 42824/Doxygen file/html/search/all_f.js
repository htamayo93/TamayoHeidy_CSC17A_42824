var searchData=
[
  ['wonlost',['wonLost',['../class_results.html#a524b5fca650bab4871cb6d99f9f81078',1,'Results']]]
];
