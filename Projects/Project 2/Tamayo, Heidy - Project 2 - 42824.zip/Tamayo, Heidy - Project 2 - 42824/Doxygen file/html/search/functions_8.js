var searchData=
[
  ['results',['results',['../class_results.html#acc0c6a11a0e0cb1aa4ad6156305833e9',1,'Results::results(string[], string[])'],['../class_results.html#ae15a9e843b67c54e98a6f59a56104e1f',1,'Results::Results()']]]
];
