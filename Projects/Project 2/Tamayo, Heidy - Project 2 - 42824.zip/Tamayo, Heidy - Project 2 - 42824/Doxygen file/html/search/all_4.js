var searchData=
[
  ['hints',['hints',['../class_results.html#aaf688f3410c9ca42e3e57432958b2760',1,'Results']]]
];
