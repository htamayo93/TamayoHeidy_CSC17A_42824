var searchData=
[
  ['playa',['playA',['../main_8cpp.html#a97a3ea6213ad4445ef192629426b6157',1,'main.cpp']]]
];
