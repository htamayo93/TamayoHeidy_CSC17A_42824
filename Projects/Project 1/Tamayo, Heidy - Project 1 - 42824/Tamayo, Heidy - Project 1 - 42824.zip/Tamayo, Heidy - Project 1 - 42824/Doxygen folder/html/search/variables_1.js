var searchData=
[
  ['change',['change',['../struct_usepick.html#acfa73efd5adceb1d77124430bd3089e7',1,'Usepick']]],
  ['choice',['choice',['../struct_usepick.html#a2f62916be784f45c1fa162159415eda7',1,'Usepick']]]
];
