var searchData=
[
  ['hints',['hints',['../main_8cpp.html#a1294fe51b13b6ec907096be1447074e0',1,'main.cpp']]]
];
